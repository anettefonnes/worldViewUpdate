
var scene, camera, renderer, rotation;
var material, earth, light, stars, worldEvent;


init();
animate();

function init(){
    var width = window.innerWidth - 20;
    var height = window.innerHeight - 20;

    scene = new THREE.Scene();

    earth = new World();
    scene.add(earth);

    //TODO - make Event list and/or controller
    var worldEvent1 = new Event(60, -2);
    earth.addEvent(worldEvent1);
    worldEvent1.addMesh(
        new THREE.Mesh(
            new THREE.SphereGeometry(2, 10,10),
            new THREE.MeshBasicMaterial({color: 0xf0ff00})
    ));
    var worldEvent2 = new Event(110, 30);
    worldEvent2.addMesh(
        new THREE.Mesh(
            new THREE.SphereGeometry(2, 10,10),
            new THREE.MeshBasicMaterial({color: 0xff0000})
        ));
    earth.addEvent(worldEvent2);
    var worldEvent3 = new Event(60,50);
    worldEvent3.addMesh(
        new THREE.Mesh(
            new THREE.SphereGeometry(2, 10,10),
            new THREE.MeshBasicMaterial({color: 0xff00ff})
        ));
    earth.addEvent(worldEvent3);

    //Does not work!
    var mid = midPoint(60, -2, 110, 30);


    //var curveObject = new CurvedLine(worldEvent1, worldEvent2, 0xff0000);
    //Line between two events
    var curve = new THREE.QuadraticBezierCurve3(
        worldEvent1.position,
        mid.clone().multiplyScalar(1.4),
        worldEvent2.position
    );
    var geom = new THREE.Geometry();
    geom.vertices = curve.getPoints( 100 );
    var material = new THREE.LineBasicMaterial( { color : 0xff0000 } );
    var curveObject = new THREE.Line( geom, material );
    scene.add(curveObject);
    earth.add(curveObject);

    camera = new THREE.PerspectiveCamera(45, width / height, 1, 10000);
    camera.position.z = 250;
    camera.position.y = 200;
 //   earth.add(camera);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(width, height);

    //light adding
    scene.add(new THREE.AmbientLight(0xe0e0e0));
    light = new THREE.DirectionalLight(0xffffff, 0.3);
    light.position.set(200,0,500);
    scene.add(light);

    stars = createStars(100, 200);
    scene.add(stars);


    //window.setInterval(changeParent(), 3000);

    document.body.appendChild(renderer.domElement);
   // document.addEventListener("keydown", keyPressed, true);
}

//TODO: Get more realistic stars. Use Parallax pixel stars / SCSS?
function createStars(rad, seg) {
    return new THREE.Mesh(
        new THREE.SphereGeometry(rad*10 , seg, seg),
        new THREE.MeshBasicMaterial({
            map:    THREE.ImageUtils.loadTexture('img/stars.png'),
            side:   THREE.BackSide
        })
    );
}

//TODO: More action in this function; rotation, light etc.?
function animate() {
    requestAnimationFrame(animate);

    earth.rotate();
    camera.lookAt(earth.position);

    renderer.render(scene, camera);
}

function toRadians(ang) {
    return ang * (Math.PI / 180);
}

//TODO: Make this function work!
function midPoint(lo1, la1, lo2, la2) {
    var lat1 = toRadians(la1), lon1 = toRadians(lo1), lat2=toRadians(la2), lon2=toRadians(lo2);
    var vec1 = new THREE.Vector3(
        Math.cos(lat1) * Math.cos(lon1),
        Math.cos(lat1) * Math.sin(lon1),
        Math.sin(lat1));
    var vec2 = new THREE.Vector3(
        Math.cos(lat2) * Math.cos(lon2),
        Math.cos(lat2) * Math.sin(lon2),
        Math.sin(lat2));

    return new THREE.Vector3(earth.rad*((vec1.x + vec2.x)/2), earth.rad*((vec1.y + vec2.y)/2), earth.rad * ((vec1.z + vec2.z)/2) );

    /*
    var Bx = Math.cos(lat2) * Math.cos(lon2-lon1);
    var By = Math.cos(lat2) * Math.sin(lon2-lon1);
    var lat3 = Math.atan2(Math.sin(lat1) + Math.sin(lat2),
        Math.sqrt( (Math.cos(lat1)+Bx)*(Math.cos(lat1)+Bx) + By*By ) );
    var lon3 = lon1 + Math.atan2(By, Math.cos(lat1) + Bx);
    return lon3; */
}

/**
 * Created by Anette on 27.02.2015.
 */

